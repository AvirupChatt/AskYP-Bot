
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Pattern;

import org.bson.Document;

import twitter4j.*;
import twitter4j.conf.ConfigurationBuilder;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.IndexOptions;

public class main {
	private static final String CONSUMER_KEY = System.getenv("CONSUMER_KEY");
	private static final String CONSUMER_SECRET = System.getenv("CONSUMER_SECRET");
	private static final String ACCESS_TOKEN = System.getenv("ACCESS_TOKEN");
	private static final String ACCESS_SECRET = System.getenv("ACCESS_SECRET");

	private static final String HASHTAG = "#abc123lmnop";
	
	private static final String mongoUri = System.getenv("MONGODB_URI");
	private static final String mongoName = System.getenv("MONGO_NAME");
	private static final String mongoPass = System.getenv("MONGO_PASS");
	private static final String mongoStr = System.getenv("MONGO_STR");
   
	private static ConfigurationBuilder cb;
	private static Twitter twitter;
	private static DBSearch dbsearch;
	
    public void impl(){
    	
    	
    	
    	
    	
    	
    	
    	
    		
    	
    		// if no item info
    			// get user favorites
    			// parse user favorites for item info
    	
    	
    	// get saved tweets on mongoDB
    		// check if response from user 
    			// if yes
    				// respond with deals
    				// delete tweet, remove relation from user
    	
    		
    }
    public static boolean postTweetReplyLocationReq(long postId, String usrname){
		try {
			StatusUpdate stat = new StatusUpdate(
					"Hey @"
							+ usrname
							+ " which city are you looking to buy the product in? Let us by tweeting #AskYP <City Name>");
			stat.setInReplyToStatusId(postId);
			twitter.updateStatus(stat);
			return true;
		} catch (TwitterException e) {
			return false;
		}
    }
    
    public static boolean postTweetReply(long postId, String usrname, String location, String keywords){
    	try {
    		FindDeals newDeals = new FindDeals();
    		newDeals.setUserInfoStringLoc(location, keywords);
    		StatusUpdate stat;

			if (newDeals.dealFound()) {
				stat = new StatusUpdate("Hey @" + usrname + ", "
						+ newDeals.getDeal());
				stat.setInReplyToStatusId(postId);
				twitter.updateStatus(stat);
			} else {
				// do something else
			}

			return true;
		} catch (TwitterException e) {
			return false;
		}
    }
    
	public static void main(String[] args) throws IOException{
		// Configure twitter
    	cb = new ConfigurationBuilder();
		cb.setOAuthConsumerKey(CONSUMER_KEY);
		cb.setOAuthConsumerSecret(CONSUMER_SECRET);
		cb.setOAuthAccessToken(ACCESS_TOKEN);
		cb.setOAuthAccessTokenSecret(ACCESS_SECRET);
		
		// Build twitter
		twitter = new TwitterFactory(cb.build()).getInstance();
		
		// start timer 
		// TODO - add timer
		
		// Get database
		dbsearch = new DBSearch(mongoName,mongoPass,mongoStr);
		double current_time = 0.0;
		 try {
			// Query with time
			// TODO - add time
			while (true) {
				if(current_time > 100.0){
				Query query = new Query(HASHTAG);
				query.setCount(10);
				QueryResult result = twitter.search(query);

				// Get Tweets
				for (Status current : result.getTweets()) {

					tweetParser tp = new tweetParser();
					User user = current.getUser();

					// Parse Tweet for item info
					String msg = current.getText();
					String item_info = tweetParser.removeStopWords(msg);
					String parsed_iteminfo = tp.parseItemInfo(item_info,
							dbsearch.db.getCollection("types"));
					// TODO - compare item_info and parsed_iteminfo
					if (parsed_iteminfo.equals(item_info)) {
						// no brands
						List<Status> fav = twitter.getFavorites(user
								.getScreenName());

						for (Status currentFav : fav) {
							String test = currentFav.getText();
							// TODO - check if has brand

							// if has brand, store in array
							// if brand already in array, increment number of
							// hits (times the word appeared in favorites)
						}
					}
					// Parse Tweet for location info
					String location_info = tp.parseLocation(item_info);

					// check mongo db to see if user has stored location
					String usr_loc = dbsearch.getTwitterUserLocation(user);
					if (usr_loc.length() <= 0) {
						// no stored location so set as twitter user location
						usr_loc = user.getLocation();
					}

					if (location_info.length() > 0) {
						postTweetReply(current.getId(), user.getScreenName(),
								location_info, item_info);
					} else if (usr_loc.length() > 0) {
						// database did not have location but user's twitter did
						// post tweet reply
						postTweetReply(current.getId(), user.getScreenName(),
								usr_loc, item_info);

						// update user location
						dbsearch.createTwitterUserObj(user);
					} else {
						// no stored location

						// respond with need for location
						postTweetReplyLocationReq(current.getId(),
								user.getScreenName());

						// save tweet and update user
						dbsearch.updateTwitterUserwithTweet(user, current,
								item_info);
					}

				}
					current_time+=0.1;
				}
			}

			  } catch (TwitterException e) {

			  }
		 
		
	}
}
